export interface CurrencyConfig {
  code: string;
  symbol: string;
  name: string;
  locale: string;
  decimals: number;
}

export const SUPPORTED_CURRENCIES: Record<string, CurrencyConfig> = {
  INR: { code: 'INR', symbol: '₹', name: 'Indian Rupee (INR)', locale: 'en-IN', decimals: 2 },
  USD: { code: 'USD', symbol: '$', name: 'US Dollar (USD)', locale: 'en-US', decimals: 2 },
  EUR: { code: 'EUR', symbol: '€', name: 'Euro (EUR)', locale: 'de-DE', decimals: 2 },
  GBP: { code: 'GBP', symbol: '£', name: 'British Pound (GBP)', locale: 'en-GB', decimals: 2 },
  CAD: { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar (CAD)', locale: 'en-CA', decimals: 2 },
  AUD: { code: 'AUD', symbol: 'A$', name: 'Australian Dollar (AUD)', locale: 'en-AU', decimals: 2 },
  JPY: { code: 'JPY', symbol: '¥', name: 'Japanese Yen (JPY)', locale: 'ja-JP', decimals: 0 },
  AED: { code: 'AED', symbol: 'AED', name: 'UAE Dirham (AED)', locale: 'ar-AE', decimals: 2 },
  SGD: { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar (SGD)', locale: 'en-SG', decimals: 2 },
};

export const DEFAULT_CURRENCY = 'USD';

export function formatCurrency(amount: number, currencyCode: string = 'USD'): string {
  const config = SUPPORTED_CURRENCIES[currencyCode] || SUPPORTED_CURRENCIES.USD;
  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);
  
  const formattedNumber = new Intl.NumberFormat(config.locale, {
    minimumFractionDigits: config.decimals,
    maximumFractionDigits: config.decimals,
  }).format(absAmount);

  const sign = isNegative ? '-' : '';
  
  // Format with symbol
  if (config.code === 'AED') {
    return `${sign}${formattedNumber} AED`;
  }
  return `${sign}${config.symbol}${formattedNumber}`;
}
